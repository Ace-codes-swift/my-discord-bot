require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, SlashCommandBuilder, Routes, REST, EmbedBuilder } = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

const rolesFolder = path.join(__dirname, 'roles');
const token = process.env.DISCORD_TOKEN;
const guildId = process.env.GUILD_ID;

// Register slash commands
const commands = [
  new SlashCommandBuilder().setName('roles').setDescription('List all available roles.'),
  new SlashCommandBuilder()
    .setName('giverole')
    .setDescription('Gives you a role from the list.')
    .addStringOption(option =>
      option.setName('role')
        .setDescription('The role to give')
        .setRequired(true)
    )
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken(token);

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);

  try {
    console.log('Registering slash commands...');
    await rest.put(Routes.applicationGuildCommands(client.application.id, guildId), { body: commands });
    console.log('Slash commands registered.');
  } catch (error) {
    console.error(error);
  }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === 'roles') {
    const roleFiles = fs.readdirSync(rolesFolder).filter(file => file.endsWith('.txt'));
    const roleNames = roleFiles.map(file => path.parse(file).name);

    const embed = new EmbedBuilder()
      .setTitle('Available Roles')
      .setDescription(roleNames.join('\n') || 'No roles found.')
      .setColor(0x00AE86);

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (interaction.commandName === 'giverole') {
    const requestedRole = interaction.options.getString('role');
    const roleFilePath = path.join(rolesFolder, `${requestedRole}.txt`);

    if (!fs.existsSync(roleFilePath)) {
      return interaction.reply({ content: `❌ Role \`${requestedRole}\` is not available.`, ephemeral: true });
    }

    const role = interaction.guild.roles.cache.find(r => r.name.toLowerCase() === requestedRole.toLowerCase());
    if (!role) {
      return interaction.reply({ content: `⚠️ Role \`${requestedRole}\` does not exist in this server.`, ephemeral: true });
    }

    try {
      await interaction.member.roles.add(role);
      return interaction.reply({ content: `✅ Role \`${role.name}\` has been given to you!`, ephemeral: true });
    } catch (err) {
      return interaction.reply({ content: `❌ Could not assign the role. Check my permissions.`, ephemeral: true });
    }
  }
});

client.login(token);